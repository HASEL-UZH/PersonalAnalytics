You need .NET 2.0 and C++ runtime or .NET 3.5 (it includes C++ runtime)

32 bits
http://www.microsoft.com/downloads/details.aspx?FamilyID=a5c84275-3b97-4ab7-a40d-3802b2af5fc2&displaylang=en

64 bits
http://www.microsoft.com/downloads/details.aspx?FamilyID=ba9257ca-337f-4b40-8c14-157cfdffee4e&displaylang=en

http://www.pixel-technology.com/freeware/tessnet2/